import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule }   from '@angular/forms';
import { RouterModule }   from '@angular/router';

import { ToolbarComponent } from '../shared/toolbar/toolbar.component';
import { NavbarComponent } from '../shared/navbar/navbar.component';
import { AppComponent }   from './app.component';
import { AffecterHeureComponent } from '../components/affecterHeure/affecterHeure.component';
import { DescriptionProfComponent } from '../components/descriptionProf/descriptionProf.component';

@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot([
      { path: 'affecterHeure', component: AffecterHeureComponent },
      { path: 'description', component: DescriptionProfComponent }
    ])
  ],
  declarations: [ AppComponent, AffecterHeureComponent, DescriptionProfComponent, ToolbarComponent, NavbarComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
