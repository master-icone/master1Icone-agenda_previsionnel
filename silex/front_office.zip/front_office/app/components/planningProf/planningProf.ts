import { Component } from '@angular/core';
@Component({
  selector: 'my-app',
  template: `
`
})

export class homeComponent { }    // € Exportation du component sous la forme du nom de class 
