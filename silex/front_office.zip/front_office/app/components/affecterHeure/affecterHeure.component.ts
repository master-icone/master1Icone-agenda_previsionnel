import { Component } from '@angular/core';
@Component({
  selector: 'affecterHeure',
  template: `<h1>Afficher Heure</h1>`
})

export class AffecterHeureComponent { }    // € Exportation du component sous la forme du nom de class
