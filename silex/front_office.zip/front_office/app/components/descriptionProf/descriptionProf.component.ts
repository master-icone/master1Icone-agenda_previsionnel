import { Component } from '@angular/core';
@Component({
  selector: 'descriptionProf',
  template: `<h1>Description prof</h1>`
})

export class DescriptionProfComponent { }    // € Exportation du component sous la forme du nom de class
