import { Component } from '@angular/core';
@Component({
  selector: 'vue_globale',
  template: `<vue-globale></vue-globale>
`
})

export class VueGlobalComponent { }    // € Exportation du component sous la forme du nom de class 
